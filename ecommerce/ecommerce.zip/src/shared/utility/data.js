

const Collection = [{

       "badge":"-20",
       "image":"https://i.pinimg.com/originals/0d/86/b1/0d86b14bb6503907498ebff62062ae12.png",
       "Title":"Headphone Gaming v589",
       "price":"$5657",
       "original_price":"$6685",

},
{
    "badge":"-10",
    "image":"https://w7.pngwing.com/pngs/206/590/png-transparent-wireless-speaker-battery-charger-loudspeaker-enclosure-bluetooth-bluetooth-electronics-bluetooth-speaker.png",
    "Title":"Bluetooth Speaker v589",
    "price":"$7655",
    "original_price":"$87675",

},
{

    "badge":"-25",
    "image":"https://e7.pngegg.com/pngimages/584/29/png-clipart-webcam-logitech-quickcam-camera-usb-video-device-class-small-black-camera-electronics-english.png",
    "Title":"Camera 3456q v589",
    "price":"$4566",
    "original_price":"$9787",
},
{

    "badge":"-25",
    "image":"https://w7.pngwing.com/pngs/50/413/png-transparent-white-earphone-white-earphone-headset-png-product-physical-drawing-thumbnail.png",
    "Title":"Ear Earphone DEWT",
    "price":"$4566",
    "original_price":"$9787",
},
{

    "badge":"-25",
    "image":"https://www.truke.in/wp-content/uploads/2021/02/truke-fit2-in-ear-bluetooth-earphones-with-mic.png",
    "Title":"Bluetooth Speaker 3487",
    "price":"$3435",
    "original_price":"$6757",
},
{

    "badge":"-25",
    "image":"https://w7.pngwing.com/pngs/69/777/png-transparent-microphone-headphones-headset-ecouteur-telephone-microphone-electronics-microphone-cable-thumbnail.png",
    "Title":"Ear Earphone 4356",
    "price":"$4566",
    "original_price":"$9787",
},
{

    "badge":"-25",
    "image":"https://w7.pngwing.com/pngs/822/787/png-transparent-microphone-headphones-bluetooth-headset-handsfree-silver-bluetooth-headset-microphone-mobile-phone-bluetooth-thumbnail.png",
    "Title":"Wireless Earbuds 23",
    "price":"$4566",
    "original_price":"$9787",
},
{

    "badge":"-25",
    "image":"https://onecart.co.in/wp-content/uploads/2022/01/Untitled-2.png",
    "Title":"Airdopes DEWT",
    "price":"$34234",
    "original_price":"$67868",
}
];

export default  Collection;
